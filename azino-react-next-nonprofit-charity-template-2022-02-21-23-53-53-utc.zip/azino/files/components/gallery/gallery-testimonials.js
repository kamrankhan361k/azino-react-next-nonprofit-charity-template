import React from "react";

const GalleryTestimonials = ({ children }) => {
  return <div className="gallery-testimonials-parallax">{children}</div>;
};

export default GalleryTestimonials;
